﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using System.Data;
using System.Data.SqlClient;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using CsvHelper;
using System.IO;

namespace RealTimeRawDataService
{
    public enum MODE
    {
        Live = 0,
        Test = 1,
        LiveTest = 2
    }

    public struct TradeSummaryPairing
    {
        public int LastIndex;
        public bool Updated;
        public List<TradeSummary> TradeList;
    }

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode=ConcurrencyMode.Multiple)] 
    public class RealTimeRawDataService : IRealTimeRawDataService
    {

        public static Dictionary<String, TradeSummary> dayTradeSummaries_AMEX_LOOKUP = new Dictionary<String, TradeSummary>();
        public static Dictionary<String, TradeSummary> dayTradeSummaries_NYSE_LOOKUP = new Dictionary<String, TradeSummary>();
        public static Dictionary<String, TradeSummary> dayTradeSummaries_NASDAQ_LOOKUP = new Dictionary<String, TradeSummary>();
        public static Dictionary<String, TradeSummary> dayTradeSummaries_LSE_LOOKUP = new Dictionary<String, TradeSummary>();

        public static Dictionary<String, TradeSummary> oneMinuteTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummary>();
        public static Dictionary<String, TradeSummary> twoMinuteTradeSummaries_FOREX_LOOKUP = new Dictionary<String, TradeSummary>();

        public static Dictionary<String, List<TradeSummary>> oneMinuteTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();
        public static Dictionary<String, List<TradeSummary>> fifteenMinuteTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();
        public static Dictionary<String, List<TradeSummary>> thrityMinuteTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();
        public static Dictionary<String, List<TradeSummary>> oneHourTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();
        public static Dictionary<String, List<TradeSummary>> twoHourTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();
        public static Dictionary<String, List<TradeSummary>> threeHourTradeSummaries_FOREX_LOOKUP = new Dictionary<String, List<TradeSummary>>();


        public static Dictionary<String, TradeSummaryPairing> oneMinuteTradeSummaries_FOREX_LOOKUP_X = new Dictionary<String, TradeSummaryPairing>();
        public static Dictionary<String, TradeSummaryPairing> fifteenMinuteTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummaryPairing>();
        public static Dictionary<String, TradeSummaryPairing> thrityMinuteTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummaryPairing>();
        public static Dictionary<String, TradeSummaryPairing> oneHourTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummaryPairing>();
        public static Dictionary<String, TradeSummaryPairing> twoHourTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummaryPairing>();
        public static Dictionary<String, TradeSummaryPairing> threeHourTradeSummaries_FOREX_LOOKUPX = new Dictionary<String, TradeSummaryPairing>();
        List<int> _intervalCount = new List<int>() { 15, 30, 60, 120, 180 };


        private static List<DateTime> twoMinuteTimeFrame = new List<DateTime>();

        public static MODE Mode;

        public RealTimeRawDataService()
        {
            DateTime today = DateTime.Today;
            //1440 min in a day
            
            for (int i = 0; i < 720; i++) //2min
            {

                TimeSpan span = new TimeSpan(0, 2, 0);

                DateTime tempNewDateTime = today + span;

                //DateTime tempNewDateTime = new DateTime(today.Year, today.Month,
                //                                        today.Day, today.Hour,
                //                                        (today.Minute + 2), 0, 0);
                today = tempNewDateTime;
                twoMinuteTimeFrame.Add(today);
            }

           
            //Temp
            Mode = MODE.Test;

            //this is for manual testing of data
            ThreadStart threadStart = new ThreadStart(InitialseDataTables);
            Thread initialseDataTablesThread = new Thread(threadStart);
            initialseDataTablesThread.Start();

        }


        public void InitialseDataTables()
        {
            PopulateDataTables();
        }

        private void PopulateDataTables()
        {
            Console.WriteLine("\n\n");

            //Starttime
            DateTime startTime = DateTime.Now;
            String triggerlogFileName = "GetAllDataX.txt";

            if (!System.IO.File.Exists(triggerlogFileName))
            {
                //crude approach
                using (System.IO.FileStream fs = System.IO.File.Create(triggerlogFileName)) { }
            }

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(triggerlogFileName, true))
            {
                file.WriteLine(String.Format("StartTime  {0}  {1}", DateTime.Now.TimeOfDay, DateTime.Now));
            }

            Console.WriteLine("Data fetching in progress");

            InitializeData();


            //end time
            TimeSpan span = DateTime.Now - startTime;

            Console.WriteLine(String.Format("EndTime {0} {1} Total :: {2}", DateTime.Now.TimeOfDay, DateTime.Now, span));

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(triggerlogFileName, true))
            {
                file.WriteLine(String.Format("EndTime  {0}  {1} Total Duration::{2}", DateTime.Now.TimeOfDay, DateTime.Now, span));
                file.WriteLine("");
            }
        }

        private void InitializeData()
        {
            String currentTitle = Console.Title;

            try
            {

                //using (StreamReader reader = new StreamReader("C:\\Users\\dowusu-ansah\\Downloads\\Data\\Template\\"
                //    + "RealTimeChartPatternRecognition\\PatternData\\HeadAndShoulders\\FOREX_EURGBP_Period 20000104 - 20140225\\EURGBP_Period 20000104 - 20140225.csv"))

                using (StreamReader reader = new StreamReader("..\\..\\..\\..\\"
                    + "..\\PatternData\\HeadAndShoulders\\FOREX_EURGBP_Period 20000104 - 20140225\\EURGBP_Period 20000104 - 20140225.csv"))
                {
                    //line = reader.ReadLine();

                     CsvReader csvReader = new CsvReader(reader);
                     while (csvReader.Read())
                     {
                         TradeSummary tradeSummary = new TradeSummary();

                         tradeSummary.DateTime = csvReader.GetField<DateTime>("DateTime");
                         tradeSummary.Open = csvReader.GetField<Double>("Open");
                         tradeSummary.High = csvReader.GetField<Double>("High");

                         tradeSummary.Low = csvReader.GetField<Double>("Low");
                         tradeSummary.Close = csvReader.GetField<Double>("Close");
                         tradeSummary.Volume = csvReader.GetField<int>("Volume");
                         //tradeSummary.TimeFrame = csvReader.GetField<String>("TimeFrame");

                         tradeSummary.TimeFrame = "1min";


                         tradeSummary.SymbolID = csvReader.GetField<String>("SymbolID");

                         SetTradeSummaryX(tradeSummary);

                     }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error :: " + ex.ToString());
            }
        }


        
        
        public void SetTradeSummaryX(TradeSummary tradeSummary)
        {
            DateTime tempNewDateTime = new DateTime(tradeSummary.DateTime.Year, tradeSummary.DateTime.Month,
                                                        tradeSummary.DateTime.Day, tradeSummary.DateTime.Hour,
                                                        tradeSummary.DateTime.Minute, 0, 0);
            tradeSummary.DateTime = tempNewDateTime;

            String lookUpID = tradeSummary.SymbolID + "#" + tradeSummary.DateTime.Ticks.ToString();

            //String log = tradeSummary.SymbolID + " :: " + tempNewDateTime.ToString() + " :: " + DateTime.Now.ToString(); 
            String log = tradeSummary.SymbolID + " :: " + tempNewDateTime.ToString() + " :: CurrentTime Log ->" + DateTime.Now.ToString();


            Console.WriteLine(log);

            oneMinuteTradeSummaries_FOREX_LOOKUPX.Add(lookUpID, tradeSummary);
        }

        public void SetTradeSummary(TradeSummary tradeSummary)
        {
            //DateTime tempNewDateTime = new DateTime(tradeSummary.DateTime.Year, tradeSummary.DateTime.Month,
            //                                            tradeSummary.DateTime.Day, tradeSummary.DateTime.Hour,
            //                                            tradeSummary.DateTime.Minute, 0, 0);

            DateTime tempNewDateTime = new DateTime(tradeSummary.DateTime.Year, tradeSummary.DateTime.Month,
                                            tradeSummary.DateTime.Day, tradeSummary.DateTime.Hour,
                                            tradeSummary.DateTime.Minute, tradeSummary.DateTime.Second, 0);

            tradeSummary.DateTime = tempNewDateTime;

            String lookUpID = tradeSummary.SymbolID;

            String log = tradeSummary.SymbolID + " :: " + tempNewDateTime.ToString() + " :: CurrentTime Log ->" + DateTime.Now.ToString();

            Console.WriteLine(log);

            List<TradeSummary> tradeSummaryList = null;
            if (oneMinuteTradeSummaries_FOREX_LOOKUP.TryGetValue(lookUpID, out tradeSummaryList))
            {
                tradeSummaryList.Add(tradeSummary);
                //update preexisiting list
            }
            else
            {
                tradeSummaryList = new List<TradeSummary>();

                tradeSummaryList.Add(tradeSummary);
                oneMinuteTradeSummaries_FOREX_LOOKUP.Add(lookUpID, tradeSummaryList);
            }

            GenerateIntervals();
        }

        private void GenerateIntervals()
        {

            if (oneMinuteTradeSummaries_FOREX_LOOKUP_X.Count() > 1)
            {
                foreach (var item in _intervalCount)
                {
                    CheckForIntervalUpdates(item);
                }
            }
        }

        private void CheckForIntervalUpdates(int intervalCount)
        {
            Dictionary<String, TradeSummaryPairing> timeFrameLookup = null;

            switch (intervalCount)
            {
                case 15:
                    {
                        timeFrameLookup = fifteenMinuteTradeSummaries_FOREX_LOOKUPX;
                    } break;

                case 30:
                    {
                        timeFrameLookup = thrityMinuteTradeSummaries_FOREX_LOOKUPX;
                    } break;

                case 60:
                    {
                        timeFrameLookup = oneHourTradeSummaries_FOREX_LOOKUPX;
                    } break;

                case 120:
                    {
                        timeFrameLookup = twoHourTradeSummaries_FOREX_LOOKUPX;
                    } break;

                case 180:
                    {
                        timeFrameLookup = threeHourTradeSummaries_FOREX_LOOKUPX;
                    } break;
            }


            if (timeFrameLookup != null)
            {
                Dictionary<String, TradeSummaryPairing> tempCollection = new Dictionary<string, TradeSummaryPairing>();

                for (int m = 0; m < timeFrameLookup.Count(); m++)
                {
                    var key = timeFrameLookup.Keys.ElementAt(m);
                    var list = timeFrameLookup[key];

                    int iter = 0;
                   // List<TradeSummary> tradeCollection = new List<TradeSummary>();

                    TradeSummaryPairing tradePairing = list;
                    //tradePairing.LastIndex = 0;
                    //tradePairing.TradeList = new List<TradeSummary>();

                    for (int t = tradePairing.LastIndex; t < list.TradeList.Count; t++)
                    {
                        if (iter == intervalCount)
                        {
                            tradePairing.LastIndex = t;
                            tradePairing.Updated = true;

                            tradePairing.TradeList.Add(list.TradeList[t]);
                            iter = 0;
                        }
                        iter++;
                    }

                    tempCollection.Add(key, tradePairing);
                }

                switch (intervalCount)
                {
                    case 15:
                        {
                            fifteenMinuteTradeSummaries_FOREX_LOOKUPX = tempCollection;
                        } break;

                    case 30:
                        {
                            thrityMinuteTradeSummaries_FOREX_LOOKUPX = tempCollection;
                        } break;

                    case 60:
                        {
                            oneHourTradeSummaries_FOREX_LOOKUPX = tempCollection;
                        } break;

                    case 120:
                        {
                            twoHourTradeSummaries_FOREX_LOOKUPX = tempCollection;
                        } break;

                    case 180:
                        {
                            threeHourTradeSummaries_FOREX_LOOKUPX = tempCollection;
                        } break;
                }


            }



        }

        //After the RT JM has generated the minute level tickets..it must call this method
        public List<UpdatedTimeFrame> GetUpdatedTimeFrameList()
        {
            List<UpdatedTimeFrame> updatedTimeFrameList = new List<UpdatedTimeFrame>();


            foreach (var item in _intervalCount)
            {
                //Go through time frames with updates and reset flags tp false
                Dictionary<String, TradeSummaryPairing> timeFrameLookup = null;

                String timeFrameStr = "";
                switch (item)
                {
                    case 15:
                        {
                            timeFrameLookup = fifteenMinuteTradeSummaries_FOREX_LOOKUPX;
                            timeFrameStr = "15min";
                        } break;

                    case 30:
                        {
                            timeFrameLookup = thrityMinuteTradeSummaries_FOREX_LOOKUPX;
                            timeFrameStr = "30min";

                        } break;

                    case 60:
                        {
                            timeFrameLookup = oneHourTradeSummaries_FOREX_LOOKUPX;
                            timeFrameStr = "1hour";

                        } break;

                    case 120:
                        {
                            timeFrameLookup = twoHourTradeSummaries_FOREX_LOOKUPX;
                            timeFrameStr = "2hour";

                        } break;

                    case 180:
                        {
                            timeFrameLookup = threeHourTradeSummaries_FOREX_LOOKUPX;
                            timeFrameStr = "3hour";

                        } break;
                }

                for (int j = 0; j < timeFrameLookup.Count;  j++)
                {
                    var key = timeFrameLookup.Keys.ElementAt(j);
                    var list = timeFrameLookup[key];
                    TradeSummaryPairing tradePairing = list;

                    if (tradePairing.Updated)
                    {
                        UpdatedTimeFrame updatedTimeFrame = new UpdatedTimeFrame();
                        updatedTimeFrame.SymbolID = key;
                        updatedTimeFrame.TimeFrame = timeFrameStr;

                        updatedTimeFrameList.Add(updatedTimeFrame);
                    }
                }
            }
            return updatedTimeFrameList;
        }


        //private void CheckForIntervalUpdates(int intervalCount)
        //{
        //    Dictionary<String, List<TradeSummary>> timeFrameLookup = null;

        //    switch (intervalCount)
        //    {
        //        case 15:
        //            {
        //                timeFrameLookup = fifteenMinuteTradeSummaries_FOREX_LOOKUP;
        //            } break;

        //        case 30:
        //            {
        //                timeFrameLookup = thrityMinuteTradeSummaries_FOREX_LOOKUP;
        //            } break;

        //        case 60:
        //            {
        //                timeFrameLookup = oneHourTradeSummaries_FOREX_LOOKUP;
        //            } break;

        //        case 120:
        //            {
        //                timeFrameLookup = twoHourTradeSummaries_FOREX_LOOKUP;
        //            } break;

        //        case 180:
        //            {
        //                timeFrameLookup = threeHourTradeSummaries_FOREX_LOOKUP;
        //            } break;
        //    }

            
        //    if (timeFrameLookup != null)
        //    {
        //        Dictionary<String, List<TradeSummary>> tempCollection = new Dictionary<string,List<TradeSummary>>();

        //        for (int m = 0; m < timeFrameLookup.Count(); m++)
        //        {
        //            var key = timeFrameLookup.Keys.ElementAt(m);
        //            var list = timeFrameLookup[key];
                    
        //            int iter = 0;
        //            List<TradeSummary> tradeCollection = new List<TradeSummary>();

        //            for (int t = 0; t < list.Count; t++)
        //            {
        //                if (iter == intervalCount)
        //                {
        //                    tradeCollection.Add(list[t]);
        //                    iter = 0;
        //                }
        //                iter++;
        //            }
        //            tempCollection.Add(key, tradeCollection);
        //        }

        //        switch (intervalCount)
        //        {
        //            case 15:
        //                {
        //                    fifteenMinuteTradeSummaries_FOREX_LOOKUP = tempCollection;
        //                } break;

        //            case 30:
        //                {
        //                    thrityMinuteTradeSummaries_FOREX_LOOKUP = tempCollection;
        //                } break;

        //            case 60:
        //                {
        //                    oneHourTradeSummaries_FOREX_LOOKUP = tempCollection;
        //                } break;

        //            case 120:
        //                {
        //                    twoHourTradeSummaries_FOREX_LOOKUP = tempCollection;
        //                } break;

        //            case 180:
        //                {
        //                    threeHourTradeSummaries_FOREX_LOOKUP = tempCollection;
        //                } break;
        //        }


        //    }



        //}

        public List<TradeSummary> GetRealTimeTradeSummaries(List<String> symbolList, int dataPoints, bool bLast, String entity, String exchange, String timeFrame)
        {
            List<TradeSummary> dtList = new List<TradeSummary>();

            TimeSpan timeSpan = new TimeSpan(0, 1, 0); //1 min

            long timeTicks = timeSpan.Ticks;

            switch (exchange)
            {
                case "LSE":
                    {
                        //List<String> lookUpIDList = new List<String>();

                        //for (int f = 0; f < symbolList.Count; f++)
                        //{
                        //    var temp = symbolList[f] + "#";

                        //    long tempCurrent = startDate.Ticks;
                        //    while (tempCurrent <= endDate.Ticks)
                        //    {
                        //        String lookUpIDTemp = temp + tempCurrent.ToString();
                        //        lookUpIDList.Add(lookUpIDTemp);

                        //        tempCurrent = tempCurrent + timeTicks;
                        //    }
                        //}

                        //for (int i = 0; i < lookUpIDList.Count; i++)
                        //{
                        //    TradeSummary resultDayTradeSum = new TradeSummary();

                        //    bool bFound = dayTradeSummaries_LSE_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                        //    if (bFound)
                        //    {
                        //        dtList.Add(resultDayTradeSum);
                        //    }
                        //}


                    } break;

                case "NASDAQ":
                    {
                        //List<String> lookUpIDList = new List<String>();

                        //for (int f = 0; f < symbolList.Count; f++)
                        //{
                        //    var temp = symbolList[f] + "#";

                        //    long tempCurrent = startDate.Ticks;
                        //    while (tempCurrent <= endDate.Ticks)
                        //    {
                        //        String lookUpIDTemp = temp + tempCurrent.ToString();
                        //        lookUpIDList.Add(lookUpIDTemp);

                        //        tempCurrent = tempCurrent + timeTicks;
                        //    }
                        //}

                        //for (int i = 0; i < lookUpIDList.Count; i++)
                        //{
                        //    TradeSummary resultDayTradeSum = new TradeSummary();

                        //    bool bFound = dayTradeSummaries_NASDAQ_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                        //    if (bFound)
                        //    {
                        //        dtList.Add(resultDayTradeSum);
                        //    }
                        //}

                    } break;

                case "NYSE":
                    {
                        //List<String> lookUpIDList = new List<String>();

                        //for (int f = 0; f < symbolList.Count; f++)
                        //{
                        //    var temp = symbolList[f] + "#";

                        //    long tempCurrent = startDate.Ticks;
                        //    while (tempCurrent <= endDate.Ticks)
                        //    {
                        //        String lookUpIDTemp = temp + tempCurrent.ToString();
                        //        lookUpIDList.Add(lookUpIDTemp);

                        //        tempCurrent = tempCurrent + timeTicks;
                        //    }
                        //}

                        //for (int i = 0; i < lookUpIDList.Count; i++)
                        //{
                        //    TradeSummary resultDayTradeSum = new TradeSummary();

                        //    bool bFound = dayTradeSummaries_NYSE_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                        //    if (bFound)
                        //    {
                        //        dtList.Add(resultDayTradeSum);
                        //    }
                        //}

                    } break;

                case "AMEX":
                    {
                        //List<String> lookUpIDList = new List<String>();

                        //for (int f = 0; f < symbolList.Count; f++)
                        //{
                        //    var temp = symbolList[f] + "#";

                        //    long tempCurrent = startDate.Ticks;
                        //    while (tempCurrent <= endDate.Ticks)
                        //    {
                        //        String lookUpIDTemp = temp + tempCurrent.ToString();
                        //        lookUpIDList.Add(lookUpIDTemp);

                        //        tempCurrent = tempCurrent + timeTicks;
                        //    }
                        //}


                        //for (int i = (lookUpIDList.Count - 2); i < lookUpIDList.Count; i++)
                        //{
                        //    TradeSummary resultDayTradeSum = new TradeSummary();

                        //    bool bFound = dayTradeSummaries_AMEX_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                        //    if (bFound)
                        //    {
                        //        dtList.Add(resultDayTradeSum);
                        //    }
                        //}

                    } break;

                case "FOREX":
                case "Forex":
                    {
                        //List<String> lookUpIDList = new List<String>();

                        //for (int f = 0; f < symbolList.Count; f++)
                        //{
                        //    var temp = symbolList[f] + "#";

                        //    long tempCurrent = startDate.Ticks;
                        //    while (tempCurrent <= endDate.Ticks)
                        //    {
                        //        String lookUpIDTemp = temp + tempCurrent.ToString();
                        //        lookUpIDList.Add(lookUpIDTemp);

                        //        tempCurrent = tempCurrent + timeTicks;
                        //    }
                        //}


                        for (int i = 0; i < symbolList.Count; i++)
                        {
                            List<TradeSummary> tradeSummaryList = null;
                            bool bFound = oneMinuteTradeSummaries_FOREX_LOOKUP.TryGetValue(symbolList[i], out tradeSummaryList);
                            if (bFound)
                            {
                                int start = tradeSummaryList.Count - dataPoints;
                                if (start > 0)
                                {
                                    for (int j = tradeSummaryList.Count - dataPoints; j < tradeSummaryList.Count; j++)
                                    {
                                        dtList.Add(tradeSummaryList[j]);
                                    }
                                }
                            }
                        }

                    } break;
            }
            return dtList;

        }

        public List<TradeSummary> GetTradeSummaries(List<String> symbolList, DateTime startDate, DateTime endDate, String exchange, String timeFrame)
        {
            List<TradeSummary> dtList = new List<TradeSummary>();

            TimeSpan timeSpan = new TimeSpan(0, 1, 0); //1 min

            long timeTicks = timeSpan.Ticks;

            switch (exchange)
            {
                case "LSE":
                    {
                        List<String> lookUpIDList = new List<String>();

                        for (int f = 0; f < symbolList.Count; f++)
                        {
                            var temp = symbolList[f] + "#";

                            long tempCurrent = startDate.Ticks;
                            while (tempCurrent <= endDate.Ticks)
                            {
                                String lookUpIDTemp = temp + tempCurrent.ToString();
                                lookUpIDList.Add(lookUpIDTemp);

                                tempCurrent = tempCurrent + timeTicks;
                            }
                        }

                        for (int i = 0; i < lookUpIDList.Count; i++)
                        {
                            TradeSummary resultDayTradeSum = new TradeSummary();

                            bool bFound = dayTradeSummaries_LSE_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                            if (bFound)
                            {
                                dtList.Add(resultDayTradeSum);
                            }
                        }


                    } break;

                case "NASDAQ":
                    {
                        List<String> lookUpIDList = new List<String>();

                        for (int f = 0; f < symbolList.Count; f++)
                        {
                            var temp = symbolList[f] + "#";

                            long tempCurrent = startDate.Ticks;
                            while (tempCurrent <= endDate.Ticks)
                            {
                                String lookUpIDTemp = temp + tempCurrent.ToString();
                                lookUpIDList.Add(lookUpIDTemp);

                                tempCurrent = tempCurrent + timeTicks;
                            }
                        }

                        for (int i = 0; i < lookUpIDList.Count; i++)
                        {
                            TradeSummary resultDayTradeSum = new TradeSummary();

                            bool bFound = dayTradeSummaries_NASDAQ_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                            if (bFound)
                            {
                                dtList.Add(resultDayTradeSum);
                            }
                        }

                    } break;

                case "NYSE":
                    {
                        List<String> lookUpIDList = new List<String>();

                        for (int f = 0; f < symbolList.Count; f++)
                        {
                            var temp = symbolList[f] + "#";

                            long tempCurrent = startDate.Ticks;
                            while (tempCurrent <= endDate.Ticks)
                            {
                                String lookUpIDTemp = temp + tempCurrent.ToString();
                                lookUpIDList.Add(lookUpIDTemp);

                                tempCurrent = tempCurrent + timeTicks;
                            }
                        }

                        for (int i = 0; i < lookUpIDList.Count; i++)
                        {
                            TradeSummary resultDayTradeSum = new TradeSummary();

                            bool bFound = dayTradeSummaries_NYSE_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                            if (bFound)
                            {
                                dtList.Add(resultDayTradeSum);
                            }
                        }

                    } break;

                case "AMEX":
                    {
                        List<String> lookUpIDList = new List<String>();

                        for (int f = 0; f < symbolList.Count; f++)
                        {
                            var temp = symbolList[f] + "#";

                            long tempCurrent = startDate.Ticks;
                            while (tempCurrent <= endDate.Ticks)
                            {
                                String lookUpIDTemp = temp + tempCurrent.ToString();
                                lookUpIDList.Add(lookUpIDTemp);

                                tempCurrent = tempCurrent + timeTicks;
                            }
                        }


                        for (int i = 0; i < lookUpIDList.Count; i++)
                        {
                            TradeSummary resultDayTradeSum = new TradeSummary();

                            bool bFound = dayTradeSummaries_AMEX_LOOKUP.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                            if (bFound)
                            {
                                dtList.Add(resultDayTradeSum);
                            }
                        }

                    } break;

                case "FOREX":
                case "Forex":
                    {
                        List<String> lookUpIDList = new List<String>();

                        for (int f = 0; f < symbolList.Count; f++)
                        {
                            var temp = symbolList[f] + "#";

                            long tempCurrent = startDate.Ticks;
                            while (tempCurrent <= endDate.Ticks)
                            {
                                String lookUpIDTemp = temp + tempCurrent.ToString();
                                lookUpIDList.Add(lookUpIDTemp);

                                tempCurrent = tempCurrent + timeTicks;
                            }
                        }


                        for (int i = 0; i < lookUpIDList.Count; i++)
                        {
                            TradeSummary resultDayTradeSum = new TradeSummary();

                            bool bFound = oneMinuteTradeSummaries_FOREX_LOOKUPX.TryGetValue(lookUpIDList[i], out resultDayTradeSum);
                            if (bFound)
                            {
                                dtList.Add(resultDayTradeSum);
                            }
                        }

                    } break;
            }
            return dtList;
        }

    }
}
